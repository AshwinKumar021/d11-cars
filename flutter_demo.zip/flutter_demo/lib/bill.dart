import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_demo/db_helper.dart';

class DetailedViewPage extends StatelessWidget {
  final Map<String, dynamic> booking;

  const DetailedViewPage({super.key, required this.booking});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: Text(
          'Booking Details',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  _buildDetailRow('Customer Name', booking['customer_name']),
                  _buildDetailRow(
                      'Customer Number', booking['customer_number']),
                  _buildDetailRow('Driving License Number',
                      booking['driving_license_number']),
                  _buildDetailRow(
                      'Aadhar Card Number', booking['aadhar_card_number']),
                  _buildDetailRow('Pickup Date', booking['pickup_date']),
                  _buildDetailRow(
                      'Start Date Time', booking['start_date_time']),
                  _buildDetailRow('Drop Date Time', booking['drop_date_time']),
                  _buildDetailRow(
                      'Fuel Range Pickup', booking['fuel_range_pickup']),
                  _buildDetailRow(
                      'Fuel Range Drop', booking['fuel_range_drop']),
                  _buildDetailRow('Odometer', booking['odometer']),
                  _buildDetailRow('No. of Days', booking['no_of_days']),
                  _buildDetailRow('Extra Hours', booking['extra_hours']),
                  _buildDetailRow('Kms', booking['kms']),
                  _buildDetailRow('Fuel', booking['fuel']),
                  _buildDetailRow('Fasttag', booking['fasttag']),
                  _buildDetailRow('Total Rent', booking['total_rent']),
                  _buildDetailRow('Trip Completed Status',
                      booking['trip_completed_status']),
                  _buildDetailRow('Created Time', booking['created_time']),
                  _buildDetailRow('Modified Time', booking['modified_time']),
                ],
              ),
            ),
            if (booking['trip_completed_status'] != 'Completed')
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () async {
                    await _completeTrip(context, booking['id']);
                  },
                  child: Text(
                    'Mark as Completed',
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '$label:',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(value ?? 'N/A', textAlign: TextAlign.end),
          ),
        ],
      ),
    );
  }

  Future<void> _completeTrip(BuildContext context, int id) async {
    final db = DatabaseHelper();
    await db.moveToCompleted(id);

    // Show a snack bar or some confirmation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Trip marked as completed')),
    );

    // Refresh the HomePage data
    Navigator.pop(context);
  }
}
