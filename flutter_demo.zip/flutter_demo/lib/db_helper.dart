import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDatabase();
    return _database!;
  }

  static Future<Database> initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'form_data.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  static void _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ongoing_bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT,
        customer_number TEXT,
        driving_license_number TEXT,
        aadhar_card_number TEXT,
        pickup_date TEXT,
        start_date_time TEXT,
        drop_date_time TEXT,
        fuel_range_pickup TEXT,
        fuel_range_drop TEXT,
        odometer TEXT,
        no_of_days TEXT,
        extra_hours TEXT,
        kms TEXT,
        fuel TEXT,
        fasttag TEXT,
        total_rent TEXT,
        trip_completed_status TEXT,
        created_time TEXT,
        modified_time TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE completed_bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT,
        customer_number TEXT,
        driving_license_number TEXT,
        aadhar_card_number TEXT,
        pickup_date TEXT,
        start_date_time TEXT,
        drop_date_time TEXT,
        fuel_range_pickup TEXT,
        fuel_range_drop TEXT,
        odometer TEXT,
        no_of_days TEXT,
        extra_hours TEXT,
        kms TEXT,
        fuel TEXT,
        fasttag TEXT,
        total_rent TEXT,
        trip_completed_status TEXT,
        created_time TEXT,
        modified_time TEXT
      )
    ''');
  }

  Future<int> insertOngoing(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert('ongoing_bookings', row);
  }

  Future<int> insertCompleted(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert('completed_bookings', row);
  }

  Future<List<Map<String, dynamic>>> queryOngoing() async {
    final db = await database;
    return await db.query('ongoing_bookings');
  }

  Future<List<Map<String, dynamic>>> queryCompleted() async {
    final db = await database;
    return await db.query('completed_bookings');
  }

  Future<int> updateOngoing(int id, Map<String, dynamic> row) async {
    final db = await database;
    return await db.update(
      'ongoing_bookings',
      row,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteOngoing(int id) async {
    final db = await database;
    return await db.delete(
      'ongoing_bookings',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteCompleted(int id) async {
    final db = await database;
    return await db.delete(
      'completed_bookings',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> moveToCompleted(int id) async {
    final db = await database;
    final row =
        await db.query('ongoing_bookings', where: 'id = ?', whereArgs: [id]);
    if (row.isNotEmpty) {
      await insertCompleted(row.first);
      await deleteOngoing(id);
    }
  }
}
