import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class GmailDrawer extends StatelessWidget {
  const GmailDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          // Profile section
          const UserAccountsDrawerHeader(
            accountName: Text('D11 Cars'),
            accountEmail: Text(''),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Color.fromARGB(255, 255, 242, 203),
              child: Text('D',
                  style: TextStyle(
                    fontSize: 40.0,
                    color: Color.fromARGB(255, 28, 87, 139),
                  )),
            ),
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 28, 87, 139),
            ),
          ),
          // Menu items
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: <Widget>[
                ListTile(
                  leading: const Icon(Icons.home),
                  title: const Text('Home'),
                  onTap: () {
                    Navigator.pop(context);
                    // Handle home tap
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.settings),
                  title: const Text('Settings'),
                  onTap: () {
                    Navigator.pop(context);
                    // Handle settings tap
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Logout'),
                  onTap: () {
                    SystemNavigator.pop();
                    // Handle logout tap
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
