import 'package:flutter/material.dart';
import 'package:flutter_demo/db_helper.dart';
import 'package:flutter_demo/logger.dart';
import 'package:intl/intl.dart';

class FormPage extends StatefulWidget {
  const FormPage({super.key});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _formValues = {};

  // Form fields controllers
  final TextEditingController _customerNameController = TextEditingController();
  final TextEditingController _customerNumberController =
      TextEditingController();
  final TextEditingController _drivingLicenseController =
      TextEditingController();
  final TextEditingController _aadharCardController = TextEditingController();
  final TextEditingController _pickupDateController = TextEditingController();
  final TextEditingController _startDateTimeController =
      TextEditingController();
  final TextEditingController _dropDateTimeController = TextEditingController();
  final TextEditingController _fuelRangePickupController =
      TextEditingController();
  final TextEditingController _fuelRangeDropController =
      TextEditingController();
  final TextEditingController _odometerController = TextEditingController();
  final TextEditingController _noOfDaysController = TextEditingController();
  final TextEditingController _extraHoursController = TextEditingController();
  final TextEditingController _kmsController = TextEditingController();
  final TextEditingController _fuelController = TextEditingController();
  final TextEditingController _fasttagController = TextEditingController();
  final TextEditingController _totalRentController = TextEditingController();
  int calculateNumberOfDays(DateTime startDate, DateTime endDate) {
    return endDate.difference(startDate).inDays;
  }

  void _updateNumberOfDays() {
    final startDateText = _startDateTimeController.text;
    final dropDateText = _dropDateTimeController.text;

    if (startDateText.isNotEmpty && dropDateText.isNotEmpty) {
      try {
        final startDate = DateFormat('dd-MM-yyyy hh:mm a').parse(startDateText);
        final dropDate = DateFormat('dd-MM-yyyy hh:mm a').parse(dropDateText);

        final daysDifference = calculateNumberOfDays(startDate, dropDate);

        setState(() {
          _noOfDaysController.text = daysDifference.toString();
        });
      } catch (e) {
        // Handle parse errors if necessary
        print('Error parsing date: $e');
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _startDateTimeController.addListener(_updateNumberOfDays);
    _dropDateTimeController.addListener(_updateNumberOfDays);
  }

  @override
  void dispose() {
    _startDateTimeController.removeListener(_updateNumberOfDays);
    _dropDateTimeController.removeListener(_updateNumberOfDays);
    super.dispose();
  }

  // Method to show date picker dialog
  Future<void> _selectDate(TextEditingController controller) async {
    DateTime initialDate = DateTime.now();
    DateTime firstDate = DateTime(1900);
    DateTime lastDate = DateTime(2100);

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (pickedDate != null) {
      // Show time picker after date selection
      final TimeOfDay? pickedTime = await _selectTime();
      if (pickedTime != null) {
        final DateTime dateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );
        setState(() {
          controller.text = DateFormat('dd-MM-yyyy hh:mm a').format(dateTime);
        });
      }
    }
  }

  // Method to show time picker dialog
  Future<TimeOfDay?> _selectTime() async {
    TimeOfDay initialTime = TimeOfDay.now();

    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: initialTime,
    );

    return pickedTime;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Color.fromARGB(255, 28, 87, 139),
        title: const Text(
          'Trip Form',
          style: TextStyle(color: Colors.white),
        ),
      ),
      bottomNavigationBar: Container(
        color: Colors.white,
        height: 70,
        width: MediaQuery.of(context).size.width,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  // Save form data
                  _formValues['customer_name'] = _customerNameController.text;
                  _formValues['customer_number'] =
                      _customerNumberController.text;
                  _formValues['driving_license_number'] =
                      _drivingLicenseController.text;
                  _formValues['aadhar_card_number'] =
                      _aadharCardController.text;
                  _formValues['pickup_date'] = _pickupDateController.text;
                  _formValues['start_date_time'] =
                      _startDateTimeController.text;
                  _formValues['drop_date_time'] = _dropDateTimeController.text;
                  _formValues['fuel_range_pickup'] =
                      _fuelRangePickupController.text;
                  _formValues['fuel_range_drop'] =
                      _fuelRangeDropController.text;
                  _formValues['odometer'] = _odometerController.text;
                  _formValues['no_of_days'] = _noOfDaysController.text;
                  _formValues['extra_hours'] = _extraHoursController.text;
                  _formValues['kms'] = _kmsController.text;
                  _formValues['fuel'] = _fuelController.text;
                  _formValues['fasttag'] = _fasttagController.text;
                  _formValues['total_rent'] = _totalRentController.text;

                  // Print form values
                  logger.f(_formValues);
                  // Insert into database
                  final dbHelper = DatabaseHelper();
                  var result = await dbHelper.insertOngoing(_formValues);
                  logger.w(result);
                  if (result != 0) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Trip Booking Saved'),
                        duration:
                            Duration(seconds: 3), // Duration of the SnackBar
                        backgroundColor: Colors.black,
                        behavior: SnackBarBehavior
                            .floating, // or SnackBarBehavior.fixed
                      ),
                    );
                  }
                  Navigator.of(context).pop();
                } catch (e) {
                  logger.e(e);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color.fromARGB(255, 28, 87, 139),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              padding: const EdgeInsets.symmetric(vertical: 15),
            ),
            child: const Text(
              'Create',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildTextFormField('Customer Name', _customerNameController,
                  (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter customer name';
                }
                return null;
              }),
              _buildTextFormField('Customer Number', _customerNumberController,
                  (value) {
                if (value == null || value.length != 10) {
                  return 'Please enter a valid 10-digit number';
                }
                return null;
              }, keyboardType: TextInputType.phone),
              _buildTextFormField(
                  'Driving License Number', _drivingLicenseController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter driving license number';
                }
                return null;
              }),
              _buildTextFormField('Aadhar Card Number', _aadharCardController,
                  (value) {
                if (value == null || value.length != 12) {
                  return 'Please enter a valid 12-digit Aadhar number';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildDateFormField('Pickup Date & Time', _pickupDateController),
              _buildDateFormField(
                  'Start Date & Time', _startDateTimeController),
              _buildDateFormField('Drop Date & Time', _dropDateTimeController),
              _buildTextFormField(
                  'Fuel Range on Pickup', _fuelRangePickupController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter fuel range on pickup';
                }
                return null;
              }),
              _buildTextFormField(
                  'Fuel Range on Drop', _fuelRangeDropController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter fuel range on drop';
                }
                return null;
              }),
              _buildTextFormField('Odometer', _odometerController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter odometer reading';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('No. of Days', _noOfDaysController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter number of days';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('Extra Hours', _extraHoursController,
                  (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter extra hours';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('Kms', _kmsController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter kilometers';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('Fuel', _fuelController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter fuel amount';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('Fast Tag Amount', _fasttagController,
                  (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter fasttag amount';
                }
                return null;
              }, keyboardType: TextInputType.number),
              _buildTextFormField('Total Rent', _totalRentController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter total rent';
                }
                return null;
              }, keyboardType: TextInputType.number),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(
    String labelText,
    TextEditingController controller,
    String? Function(String?) validator, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          labelText: labelText,
          border: OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(10), // Border radius for the field
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        ),
        keyboardType: keyboardType,
        validator: validator,
        onChanged: validator,
      ),
    );
  }

  Widget _buildDateFormField(
    String labelText,
    TextEditingController controller,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        controller: controller,
        readOnly: true,
        decoration: InputDecoration(
          labelText: labelText,
          suffixIcon: IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(controller),
          ),
          border: OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(10), // Border radius for the field
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter a date and time';
          }
          return null;
        },
      ),
    );
  }
}
