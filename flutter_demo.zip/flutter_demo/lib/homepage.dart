import 'package:flutter/material.dart';
import 'package:flutter_demo/bill.dart';
import 'package:flutter_demo/db_helper.dart';
import 'package:flutter_demo/drawer_page.dart';
import 'package:flutter_demo/form_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Future<List<Map<String, dynamic>>>? _ongoingBookingsFuture;
  Future<List<Map<String, dynamic>>>? _completedBookingsFuture;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadData();
  }

  void _loadData() {
    _ongoingBookingsFuture = DatabaseHelper().queryOngoing();
    _completedBookingsFuture = DatabaseHelper().queryCompleted();
    _completedBookingsFuture?.then((value) => value.forEach(
          (element) {
            print(element);
          },
        ));
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return const FormPage();
          }));
        },
      ),
      drawer: SizedBox(width: 350, child: const GmailDrawer()),
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: () {
              _loadData();
              setState(() {});
            },
            icon: Icon(
              Icons.sync,
              color: Colors.white,
            ),
          ),
        ],
        elevation: 0,
        title: const Text(
          'Bookings',
          style: const TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500),
        ),
        bottom: TabBar(
          controller: _tabController,
          onTap: (val) async {
            _loadData();
            setState(() {});
          },
          unselectedLabelStyle: const TextStyle(
              color: Colors.grey, fontSize: 16, fontWeight: FontWeight.w400),
          labelStyle: const TextStyle(
              color: Colors.amber, fontSize: 16, fontWeight: FontWeight.w500),
          tabs: const [
            Tab(
              text: 'Ongoing Cars',
            ),
            Tab(text: 'Completed Bookings'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _ongoingBookingsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return Center(child: Text('No ongoing bookings available'));
              } else {
                final bookings = snapshot.data!;

                return ListView.builder(
                  itemCount: bookings.length,
                  itemBuilder: (context, index) {
                    final booking = bookings[index];
                    return Card(
                        margin: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 16),
                        elevation: 4,
                        child: ListTile(
                          leading: Icon(
                            size: 50,
                            booking['trip_completed_status'] == 'Completed'
                                ? Icons.car_crash_sharp
                                : Icons.car_rental_rounded,
                            color:
                                booking['trip_completed_status'] == 'Completed'
                                    ? Colors.green
                                    : Color.fromARGB(255, 220, 199, 15),
                          ),
                          contentPadding: EdgeInsets.all(16),
                          title: Text(
                            booking['customer_name'] ?? 'No name',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                          trailing: Icon(Icons.arrow_forward_ios_rounded),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Pickup: ${booking['pickup_date']}',
                                  style: TextStyle(color: Colors.grey[700])),
                              Text('Start: ${booking['start_date_time']}',
                                  style: TextStyle(color: Colors.grey[700])),
                              Text('Drop: ${booking['drop_date_time']}',
                                  style: TextStyle(color: Colors.grey[700])),
                            ],
                          ),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      DetailedViewPage(booking: booking),
                                )).then((value) {
                              _loadData();
                              setState(() {});
                            });
                          },
                        ));
                  },
                );
              }
            },
          ),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _completedBookingsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return Center(child: Text('No completed bookings available'));
              } else {
                final bookings = snapshot.data!;

                return ListView.builder(
                  itemCount: bookings.length,
                  itemBuilder: (context, index) {
                    final booking = bookings[index];
                    return Card(
                        margin:
                            EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                        elevation: 4,
                        child: ListTile(
                          contentPadding: EdgeInsets.all(16),
                          title: Text(
                            booking['customer_name'] ?? 'No name',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 18),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Pickup: ${booking['pickup_date']}',
                                  style: TextStyle(color: Colors.grey[700])),
                              Text('Start: ${booking['start_date_time']}',
                                  style: TextStyle(color: Colors.grey[700])),
                              Text('Drop: ${booking['drop_date_time']}',
                                  style: TextStyle(color: Colors.grey[700])),
                            ],
                          ),
                          trailing: Icon(Icons.arrow_forward_ios_rounded),
                          leading: Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 50,
                          ),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      DetailedViewPage(booking: booking),
                                ));
                          },
                        ));
                  },
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
