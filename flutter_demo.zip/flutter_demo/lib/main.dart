import 'package:flutter/material.dart';
import 'package:flutter_demo/db_helper.dart';
import 'package:flutter_demo/splashScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseHelper.initDatabase();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'D11 Cars',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          color: Color.fromARGB(255, 28, 87, 139),
        ),
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Color.fromARGB(255, 28, 87, 139),
        ),
        useMaterial3: true,
      ),
      home: const Splashscreen(),
    );
  }
}
